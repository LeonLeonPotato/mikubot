#pragma once

#include "liblvgl/widgets/lv_img.h"

namespace gifs {
    LV_IMG_DECLARE(kaito_miku)
    LV_IMG_DECLARE(funny_dance_miku)
}